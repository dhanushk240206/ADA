#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void merge(int arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int leftArr[n1], rightArr[n2];

    for (int i = 0; i < n1; i++)
        leftArr[i] = arr[left + i];
    for (int i = 0; i < n2; i++)
        rightArr[i] = arr[mid + 1 + i];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (leftArr[i] <= rightArr[j]) {
            arr[k++] = leftArr[i++];
        } else {
            arr[k++] = rightArr[j++];
        }
    }

    while (i < n1)
        arr[k++] = leftArr[i++];

    while (j < n2)
        arr[k++] = rightArr[j++];
}

void mergeSort(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        merge(arr, left, mid, right);
    }
}

void generateRandomArray(int arr[], int N) {
    for (int i = 0; i < N; i++) {
        arr[i] = rand() % 1000;
    }
}

void printArray(int arr[], int N) {
    for (int i = 0; i < N; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int N, choice;

    printf("Enter the number of elements: ");
    scanf("%d", &N);

    int arr[N];

    printf("Choose the input method:\n");
    printf("1. Random Array\n");
    printf("2. Manual Input Array\n");
    printf("Enter your choice (1 or 2): ");
    scanf("%d", &choice);

    if (choice == 1) {
        generateRandomArray(arr, N);
    } else if (choice == 2) {
        printf("Enter the elements:\n");
        for (int i = 0; i < N; i++) {
            scanf("%d", &arr[i]);
        }
    } else {
        printf("Invalid choice! Exiting...\n");
        return 1;
    }

    clock_t start = clock();
    mergeSort(arr, 0, N - 1);
    clock_t end = clock();

    double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;

    if (choice == 2) {
        printf("Sorted array:\n");
        printArray(arr, N);
    }

    printf("Time taken to sort: %.6f seconds\n", time_taken);

    return 0;
}
